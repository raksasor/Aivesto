// Simulated gold price data service
import { format } from 'date-fns';

interface GoldPriceData {
  price: number;
  change: number;
  changePercent: number;
  high: number;
  low: number;
  lastUpdate: string;
}

interface HistoricalPrice {
  time: string;
  open: number;
  high: number;
  low: number;
  close: number;
}

// Initial gold price (in USD)
let currentPrice = 2250.75;
let highPrice = currentPrice * 1.01;
let lowPrice = currentPrice * 0.99;

// Simulate price change
const simulatePriceChange = (): GoldPriceData => {
  // Random price change between -0.5% and +0.5%
  const changePercent = Math.random() * 1 - 0.5;
  const change = (currentPrice * changePercent) / 100;
  
  // Update current price
  currentPrice += change;
  
  // Update high and low if needed
  if (currentPrice > highPrice) highPrice = currentPrice;
  if (currentPrice < lowPrice) lowPrice = currentPrice;
  
  return {
    price: parseFloat(currentPrice.toFixed(2)),
    change: parseFloat(change.toFixed(2)),
    changePercent: parseFloat(changePercent.toFixed(2)),
    high: parseFloat(highPrice.toFixed(2)),
    low: parseFloat(lowPrice.toFixed(2)),
    lastUpdate: format(new Date(), 'HH:mm:ss')
  };
};

// Generate historical data for charts
const generateHistoricalData = (days: number = 30): HistoricalPrice[] => {
  const data: HistoricalPrice[] = [];
  let basePrice = 2200;
  
  for (let i = days; i >= 0; i--) {
    const date = new Date();
    date.setDate(date.getDate() - i);
    
    // Add some randomness to create realistic price movements
    const volatility = Math.random() * 20 - 10; // -10 to +10
    
    // Create a slight upward trend
    const trend = i > days / 2 ? -0.5 : 0.7;
    
    basePrice += trend + volatility;
    
    const dayVolatility = Math.random() * 15;
    const high = basePrice + dayVolatility;
    const low = basePrice - dayVolatility;
    const open = basePrice - 5 + Math.random() * 10;
    const close = basePrice - 5 + Math.random() * 10;
    
    data.push({
      time: format(date, 'yyyy-MM-dd'),
      open: parseFloat(open.toFixed(2)),
      high: parseFloat(high.toFixed(2)),
      low: parseFloat(low.toFixed(2)),
      close: parseFloat(close.toFixed(2))
    });
  }
  
  // Set the last entry to match current price
  const lastEntry = data[data.length - 1];
  lastEntry.close = currentPrice;
  
  return data;
};

// Simulate intraday data for detailed charts
const generateIntradayData = (hours: number = 24): HistoricalPrice[] => {
  const data: HistoricalPrice[] = [];
  let basePrice = currentPrice - 10;
  
  for (let i = hours; i >= 0; i--) {
    const date = new Date();
    date.setHours(date.getHours() - i);
    
    // Add some randomness to create realistic price movements
    const volatility = Math.random() * 5 - 2.5; // -2.5 to +2.5
    
    basePrice += volatility;
    
    const hourVolatility = Math.random() * 3;
    const high = basePrice + hourVolatility;
    const low = basePrice - hourVolatility;
    const open = basePrice - 1 + Math.random() * 2;
    const close = basePrice - 1 + Math.random() * 2;
    
    data.push({
      time: format(date, 'HH:mm'),
      open: parseFloat(open.toFixed(2)),
      high: parseFloat(high.toFixed(2)),
      low: parseFloat(low.toFixed(2)),
      close: parseFloat(close.toFixed(2))
    });
  }
  
  // Set the last entry to match current price
  const lastEntry = data[data.length - 1];
  lastEntry.close = currentPrice;
  
  return data;
};

// Compute technical indicators
const calculateRSI = (prices: number[], period: number = 14): number[] => {
  const rsiValues: number[] = [];
  
  // Simple RSI implementation
  for (let i = period; i < prices.length; i++) {
    let gainSum = 0;
    let lossSum = 0;
    
    for (let j = i - period + 1; j <= i; j++) {
      const change = prices[j] - prices[j - 1];
      if (change >= 0) {
        gainSum += change;
      } else {
        lossSum -= change;
      }
    }
    
    const avgGain = gainSum / period;
    const avgLoss = lossSum / period;
    
    const rs = avgGain / (avgLoss === 0 ? 0.001 : avgLoss); // Avoid division by zero
    const rsi = 100 - (100 / (1 + rs));
    
    rsiValues.push(parseFloat(rsi.toFixed(2)));
  }
  
  // Pad the beginning with null values
  const padding = Array(period).fill(null);
  return [...padding, ...rsiValues];
};

// Compute MACD
const calculateMACD = (prices: number[]): { macd: number[]; signal: number[]; histogram: number[] } => {
  // Simple MACD implementation
  const ema12 = calculateEMA(prices, 12);
  const ema26 = calculateEMA(prices, 26);
  const macdLine = ema12.map((value, i) => value - ema26[i]);
  const signalLine = calculateEMA(macdLine, 9);
  const histogram = macdLine.map((value, i) => value - signalLine[i]);
  
  return {
    macd: macdLine.map(value => parseFloat(value.toFixed(2))),
    signal: signalLine.map(value => parseFloat(value.toFixed(2))),
    histogram: histogram.map(value => parseFloat(value.toFixed(2)))
  };
};

// Calculate EMA (Exponential Moving Average)
const calculateEMA = (prices: number[], period: number): number[] => {
  const ema: number[] = [];
  const multiplier = 2 / (period + 1);
  
  // Start with SMA
  let sum = 0;
  for (let i = 0; i < period; i++) {
    sum += prices[i];
  }
  
  ema.push(sum / period);
  
  // Calculate EMA
  for (let i = period; i < prices.length; i++) {
    ema.push((prices[i] - ema[ema.length - 1]) * multiplier + ema[ema.length - 1]);
  }
  
  return ema;
};

// Calculate Moving Averages
const calculateMA = (prices: number[], period: number): number[] => {
  const ma: number[] = [];
  
  for (let i = 0; i < prices.length; i++) {
    if (i < period - 1) {
      ma.push(null);
      continue;
    }
    
    let sum = 0;
    for (let j = i - period + 1; j <= i; j++) {
      sum += prices[j];
    }
    
    ma.push(parseFloat((sum / period).toFixed(2)));
  }
  
  return ma;
};

// Get AI prediction (simulated)
const getAIPrediction = () => {
  const shortTermChange = Math.random() * 2 - 0.5; // -0.5% to +1.5%
  const midTermChange = Math.random() * 5 - 1; // -1% to +4%
  const longTermChange = Math.random() * 15 - 3; // -3% to +12%
  
  return {
    shortTerm: {
      price: parseFloat((currentPrice * (1 + shortTermChange / 100)).toFixed(2)),
      change: parseFloat(shortTermChange.toFixed(2)),
      confidence: Math.round(75 + Math.random() * 20) // 75-95%
    },
    midTerm: {
      price: parseFloat((currentPrice * (1 + midTermChange / 100)).toFixed(2)),
      change: parseFloat(midTermChange.toFixed(2)),
      confidence: Math.round(65 + Math.random() * 20) // 65-85%
    },
    longTerm: {
      price: parseFloat((currentPrice * (1 + longTermChange / 100)).toFixed(2)),
      change: parseFloat(longTermChange.toFixed(2)),
      confidence: Math.round(50 + Math.random() * 30) // 50-80%
    },
    sentiment: shortTermChange > 0 ? 'bullish' : shortTermChange < -0.2 ? 'bearish' : 'neutral',
    signal: midTermChange > 1 ? 'buy' : midTermChange < -0.5 ? 'sell' : 'hold'
  };
};

export {
  simulatePriceChange,
  generateHistoricalData,
  generateIntradayData,
  calculateRSI,
  calculateMACD,
  calculateMA,
  getAIPrediction,
  type GoldPriceData,
  type HistoricalPrice
};
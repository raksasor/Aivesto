import React, { useState, useEffect } from 'react';
import { format } from 'date-fns';
import { useLanguage } from '../../context/LanguageContext';
import { generateHistoricalData, HistoricalPrice } from '../../services/goldPriceService';

interface TimeframeOption {
  label: string;
  days: number;
}

const PriceChart: React.FC = () => {
  const [historicalData, setHistoricalData] = useState<HistoricalPrice[]>([]);
  const [selectedTimeframe, setSelectedTimeframe] = useState<number>(30);
  const [Chart, setChart] = useState<any>(null);
  const { t } = useLanguage();
  
  useEffect(() => {
    // Dynamically import the chart component
    import('react-apexcharts').then((mod) => {
      setChart(() => mod.default);
    });
  }, []);
  
  const timeframeOptions: TimeframeOption[] = [
    { label: '1W', days: 7 },
    { label: '1M', days: 30 },
    { label: '3M', days: 90 },
    { label: '6M', days: 180 },
    { label: '1Y', days: 365 }
  ];
  
  useEffect(() => {
    setHistoricalData(generateHistoricalData(selectedTimeframe));
  }, [selectedTimeframe]);
  
  const chartOptions = {
    chart: {
      type: 'candlestick',
      height: 350,
      toolbar: {
        show: false
      },
      background: 'transparent',
      animations: {
        enabled: true,
        easing: 'easeinout',
        speed: 800,
        animateGradually: {
          enabled: true,
          delay: 150
        },
        dynamicAnimation: {
          enabled: true,
          speed: 350
        }
      }
    },
    xaxis: {
      type: 'category',
      labels: {
        formatter: function(val) {
          return format(new Date(val), 'MMM dd');
        }
      },
      tickAmount: 6
    },
    yaxis: {
      tooltip: {
        enabled: true
      },
      opposite: true
    },
    grid: {
      borderColor: '#f1f1f1',
      strokeDashArray: 3
    },
    plotOptions: {
      candlestick: {
        colors: {
          upward: '#10B981',
          downward: '#EF4444'
        },
        wick: {
          useFillColor: true,
        }
      }
    },
    tooltip: {
      theme: 'dark',
      x: {
        formatter: function(val) {
          return format(new Date(val), 'MMMM dd, yyyy');
        }
      }
    },
    responsive: [
      {
        breakpoint: 768,
        options: {
          chart: {
            height: 300
          }
        }
      }
    ]
  };
  
  const series = [{
    data: historicalData.map(item => ({
      x: new Date(item.time),
      y: [item.open, item.high, item.low, item.close]
    }))
  }];
  
  return (
    <div className="card animate-slide-up">
      <div className="flex justify-between items-center mb-4">
        <h2 className="text-lg font-semibold text-gray-800 dark:text-white">{t('priceChart')}</h2>
        
        <div className="flex bg-gray-100 dark:bg-gray-800 rounded-lg overflow-hidden">
          {timeframeOptions.map((option) => (
            <button
              key={option.days}
              className={`px-3 py-1 text-sm font-medium transition-colors duration-200 ${
                selectedTimeframe === option.days 
                  ? 'bg-primary-500 text-white' 
                  : 'text-gray-600 dark:text-gray-300 hover:bg-gray-200 dark:hover:bg-gray-700'
              }`}
              onClick={() => setSelectedTimeframe(option.days)}
            >
              {option.label}
            </button>
          ))}
        </div>
      </div>
      
      <div>
        {Chart && (
          <Chart
            options={chartOptions}
            series={series}
            type="candlestick"
            height={350}
          />
        )}
      </div>
    </div>
  );
};

export default PriceChart;
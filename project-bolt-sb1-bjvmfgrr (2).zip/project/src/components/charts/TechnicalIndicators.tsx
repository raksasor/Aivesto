import React, { useState, useEffect } from 'react';
import { useLanguage } from '../../context/LanguageContext';
import { 
  generateHistoricalData, 
  calculateRSI, 
  calculateMACD, 
  calculateMA 
} from '../../services/goldPriceService';

interface IndicatorOption {
  id: string;
  label: string;
}

const TechnicalIndicators: React.FC = () => {
  const [closePrices, setClosePrices] = useState<number[]>([]);
  const [dates, setDates] = useState<string[]>([]);
  const [selectedIndicator, setSelectedIndicator] = useState<string>('rsi');
  const [Chart, setChart] = useState<any>(null);
  const { t } = useLanguage();
  
  useEffect(() => {
    // Dynamically import the chart component
    import('react-apexcharts').then((mod) => {
      setChart(() => mod.default);
    });
  }, []);
  
  const indicatorOptions: IndicatorOption[] = [
    { id: 'rsi', label: t('rsi') },
    { id: 'macd', label: t('macd') },
    { id: 'ma', label: t('movingAverages') }
  ];
  
  useEffect(() => {
    const data = generateHistoricalData(90);
    setClosePrices(data.map(item => item.close));
    setDates(data.map(item => item.time));
  }, []);
  
  const renderIndicatorChart = () => {
    if (!Chart) return null;
    
    switch (selectedIndicator) {
      case 'rsi':
        return renderRSIChart();
      case 'macd':
        return renderMACDChart();
      case 'ma':
        return renderMAChart();
      default:
        return renderRSIChart();
    }
  };
  
  const renderRSIChart = () => {
    const rsiValues = calculateRSI(closePrices);
    
    const options = {
      chart: {
        type: 'line',
        height: 250,
        toolbar: {
          show: false
        },
        animations: {
          enabled: true
        }
      },
      stroke: {
        curve: 'smooth',
        width: 2
      },
      xaxis: {
        categories: dates,
        labels: {
          show: false
        }
      },
      yaxis: {
        min: 0,
        max: 100,
        tickAmount: 5,
        labels: {
          formatter: (value) => `${value.toFixed(0)}`
        }
      },
      colors: ['#2563EB'],
      grid: {
        borderColor: '#f1f1f1',
        strokeDashArray: 3
      },
      tooltip: {
        theme: 'dark'
      },
      annotations: {
        yaxis: [
          {
            y: 70,
            borderColor: '#EF4444',
            label: {
              text: 'Overbought',
              style: {
                color: '#fff',
                background: '#EF4444'
              }
            }
          },
          {
            y: 30,
            borderColor: '#10B981',
            label: {
              text: 'Oversold',
              style: {
                color: '#fff',
                background: '#10B981'
              }
            }
          }
        ]
      }
    };
    
    const series = [
      {
        name: 'RSI',
        data: rsiValues.filter(value => value !== null)
      }
    ];
    
    return (
      <Chart
        options={options}
        series={series}
        type="line"
        height={250}
      />
    );
  };
  
  const renderMACDChart = () => {
    const macdData = calculateMACD(closePrices);
    
    const options = {
      chart: {
        type: 'line',
        height: 250,
        toolbar: {
          show: false
        },
        animations: {
          enabled: true
        }
      },
      stroke: {
        curve: 'smooth',
        width: 2
      },
      xaxis: {
        categories: dates.slice(26), // MACD starts after 26 periods
        labels: {
          show: false
        }
      },
      yaxis: {
        tickAmount: 5,
        labels: {
          formatter: (value) => `${value.toFixed(1)}`
        }
      },
      colors: ['#2563EB', '#EF4444', '#10B981'],
      grid: {
        borderColor: '#f1f1f1',
        strokeDashArray: 3
      },
      tooltip: {
        theme: 'dark'
      },
      plotOptions: {
        bar: {
          columnWidth: '80%'
        }
      }
    };
    
    const series = [
      {
        name: 'MACD',
        type: 'line',
        data: macdData.macd.slice(26)
      },
      {
        name: 'Signal',
        type: 'line',
        data: macdData.signal.slice(26)
      },
      {
        name: 'Histogram',
        type: 'bar',
        data: macdData.histogram.slice(26)
      }
    ];
    
    return (
      <Chart
        options={options}
        series={series}
        type="line"
        height={250}
      />
    );
  };
  
  const renderMAChart = () => {
    const ma50 = calculateMA(closePrices, 50);
    const ma200 = calculateMA(closePrices, 200);
    
    const options = {
      chart: {
        type: 'line',
        height: 250,
        toolbar: {
          show: false
        },
        animations: {
          enabled: true
        }
      },
      stroke: {
        curve: 'smooth',
        width: [3, 2, 2]
      },
      xaxis: {
        categories: dates,
        labels: {
          show: false
        }
      },
      yaxis: {
        labels: {
          formatter: (value) => `$${value.toFixed(0)}`
        }
      },
      colors: ['#FFD700', '#2563EB', '#EF4444'],
      grid: {
        borderColor: '#f1f1f1',
        strokeDashArray: 3
      },
      tooltip: {
        theme: 'dark'
      },
      legend: {
        position: 'top'
      }
    };
    
    const series = [
      {
        name: 'Gold Price',
        data: closePrices
      },
      {
        name: 'MA50',
        data: ma50
      },
      {
        name: 'MA200',
        data: ma200
      }
    ];
    
    return (
      <Chart
        options={options}
        series={series}
        type="line"
        height={250}
      />
    );
  };
  
  return (
    <div className="card animate-slide-up">
      <div className="flex justify-between items-center mb-4">
        <h2 className="text-lg font-semibold text-gray-800 dark:text-white">{t('technicalAnalysis')}</h2>
        
        <div className="flex bg-gray-100 dark:bg-gray-800 rounded-lg overflow-hidden">
          {indicatorOptions.map((option) => (
            <button
              key={option.id}
              className={`px-3 py-1 text-sm font-medium transition-colors duration-200 ${
                selectedIndicator === option.id 
                  ? 'bg-primary-500 text-white' 
                  : 'text-gray-600 dark:text-gray-300 hover:bg-gray-200 dark:hover:bg-gray-700'
              }`}
              onClick={() => setSelectedIndicator(option.id)}
            >
              {option.label}
            </button>
          ))}
        </div>
      </div>
      
      <div>
        {renderIndicatorChart()}
      </div>
    </div>
  );
};

export default TechnicalIndicators;
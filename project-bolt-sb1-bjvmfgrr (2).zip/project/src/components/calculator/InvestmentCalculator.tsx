import React, { useState, useEffect } from 'react';
import { useLanguage } from '../../context/LanguageContext';
import { getAIPrediction } from '../../services/goldPriceService';

const InvestmentCalculator: React.FC = () => {
  const [investmentAmount, setInvestmentAmount] = useState<number>(1000);
  const [predictedReturn, setPredictedReturn] = useState<{
    shortTerm: number;
    midTerm: number;
    longTerm: number;
  }>({
    shortTerm: 0,
    midTerm: 0,
    longTerm: 0
  });
  const [loading, setLoading] = useState<boolean>(false);
  const { t } = useLanguage();
  
  const calculateReturns = () => {
    setLoading(true);
    
    // Simulate calculation delay
    setTimeout(() => {
      const prediction = getAIPrediction();
      
      setPredictedReturn({
        shortTerm: parseFloat((investmentAmount * (1 + prediction.shortTerm.change / 100) - investmentAmount).toFixed(2)),
        midTerm: parseFloat((investmentAmount * (1 + prediction.midTerm.change / 100) - investmentAmount).toFixed(2)),
        longTerm: parseFloat((investmentAmount * (1 + prediction.longTerm.change / 100) - investmentAmount).toFixed(2))
      });
      
      setLoading(false);
    }, 1000);
  };
  
  useEffect(() => {
    calculateReturns();
  }, []);
  
  return (
    <div className="card-glass animate-slide-up">
      <div className="mb-4">
        <h2 className="text-lg font-semibold text-gray-800 dark:text-white mb-4">
          {t('investmentCalculator')}
        </h2>
        
        <div className="mb-6">
          <label htmlFor="amount" className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">
            {t('investmentAmount')} ($)
          </label>
          <input
            type="number"
            id="amount"
            value={investmentAmount}
            onChange={(e) => setInvestmentAmount(Number(e.target.value))}
            className="input"
            min="1"
          />
        </div>
        
        <button
          onClick={calculateReturns}
          disabled={loading}
          className="btn btn-primary w-full mb-6"
        >
          {loading ? (
            <span className="flex items-center justify-center">
              <svg className="animate-spin -ml-1 mr-2 h-4 w-4 text-white" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24">
                <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4"></circle>
                <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path>
              </svg>
              {t('calculatingText')}...
            </span>
          ) : (
            t('calculateReturn')
          )}
        </button>
      </div>
      
      <div className="bg-gray-50 dark:bg-gray-800/50 rounded-lg p-4">
        <h3 className="text-md font-medium text-gray-800 dark:text-white mb-3">
          {t('predictedReturn')}
        </h3>
        
        <div className="space-y-4">
          <div className="flex justify-between">
            <span className="text-gray-600 dark:text-gray-400">{t('shortTerm')}</span>
            <span className={`font-medium ${predictedReturn.shortTerm >= 0 ? 'text-success-500' : 'text-error-500'}`}>
              {predictedReturn.shortTerm >= 0 ? '+' : ''}${predictedReturn.shortTerm}
            </span>
          </div>
          
          <div className="flex justify-between">
            <span className="text-gray-600 dark:text-gray-400">{t('midTerm')}</span>
            <span className={`font-medium ${predictedReturn.midTerm >= 0 ? 'text-success-500' : 'text-error-500'}`}>
              {predictedReturn.midTerm >= 0 ? '+' : ''}${predictedReturn.midTerm}
            </span>
          </div>
          
          <div className="flex justify-between">
            <span className="text-gray-600 dark:text-gray-400">{t('longTerm')}</span>
            <span className={`font-medium ${predictedReturn.longTerm >= 0 ? 'text-success-500' : 'text-error-500'}`}>
              {predictedReturn.longTerm >= 0 ? '+' : ''}${predictedReturn.longTerm}
            </span>
          </div>
        </div>
        
        <button className="btn btn-secondary w-full mt-6">
          {t('investNow')}
        </button>
      </div>
    </div>
  );
};

export default InvestmentCalculator;
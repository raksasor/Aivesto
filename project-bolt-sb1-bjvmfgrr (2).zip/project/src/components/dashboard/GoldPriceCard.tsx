import React, { useState, useEffect } from 'react';
import { TrendingUp, TrendingDown } from 'lucide-react';
import { simulatePriceChange, GoldPriceData } from '../../services/goldPriceService';
import { useLanguage } from '../../context/LanguageContext';

const GoldPriceCard: React.FC = () => {
  const [priceData, setPriceData] = useState<GoldPriceData>({
    price: 2250.75,
    change: 0,
    changePercent: 0,
    high: 2260.75,
    low: 2240.75,
    lastUpdate: '00:00:00'
  });
  const [priceIncreasing, setPriceIncreasing] = useState<boolean | null>(null);
  const { t } = useLanguage();
  
  useEffect(() => {
    // Update price every 3 seconds
    const interval = setInterval(() => {
      const newPriceData = simulatePriceChange();
      setPriceIncreasing(newPriceData.price > priceData.price);
      setPriceData(newPriceData);
    }, 3000);
    
    return () => clearInterval(interval);
  }, [priceData]);
  
  return (
    <div className="card-glass animate-slide-up">
      <div className="flex justify-between items-center mb-4">
        <h2 className="text-lg font-semibold text-gray-800 dark:text-white">{t('goldPrice')}</h2>
        <div className="text-xs text-gray-500 dark:text-gray-400">
          {t('lastUpdate')}: {priceData.lastUpdate}
        </div>
      </div>
      
      <div className="flex items-center justify-center mb-4">
        <div className="text-4xl font-bold text-primary-600 dark:text-primary-500 transition-all duration-500">
          ${priceData.price.toFixed(2)}
        </div>
        
        <div className={`
          mr-3 px-2 py-1 rounded-lg flex items-center text-sm font-medium
          ${priceData.changePercent >= 0 
            ? 'bg-success-500/10 text-success-600 dark:text-success-500' 
            : 'bg-error-500/10 text-error-600 dark:text-error-500'}
        `}>
          {priceData.changePercent >= 0 
            ? <TrendingUp size={16} className="ml-1" /> 
            : <TrendingDown size={16} className="ml-1" />}
          {priceData.changePercent >= 0 ? '+' : ''}{priceData.changePercent}%
        </div>
      </div>
      
      <div className="grid grid-cols-2 gap-4 text-sm">
        <div className="bg-gray-50 dark:bg-gray-800/50 p-2 rounded">
          <div className="text-gray-500 dark:text-gray-400">{t('highPrice')}</div>
          <div className="font-medium">${priceData.high.toFixed(2)}</div>
        </div>
        
        <div className="bg-gray-50 dark:bg-gray-800/50 p-2 rounded">
          <div className="text-gray-500 dark:text-gray-400">{t('lowPrice')}</div>
          <div className="font-medium">${priceData.low.toFixed(2)}</div>
        </div>
      </div>
      
      {/* Animated price indicator */}
      {priceIncreasing !== null && (
        <div className={`
          w-full h-1 mt-4 rounded-full transition-all duration-300
          ${priceIncreasing 
            ? 'bg-gradient-to-r from-primary-500 to-success-500' 
            : 'bg-gradient-to-r from-primary-500 to-error-500'}
        `}></div>
      )}
    </div>
  );
};

export default GoldPriceCard;
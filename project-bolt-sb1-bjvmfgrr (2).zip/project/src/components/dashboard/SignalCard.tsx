import React, { useState, useEffect } from 'react';
import { ArrowUpCircle, ArrowDownCircle, MinusCircle } from 'lucide-react';
import { getAIPrediction } from '../../services/goldPriceService';
import { useLanguage } from '../../context/LanguageContext';

const SignalCard: React.FC = () => {
  const [signal, setSignal] = useState<'buy' | 'sell' | 'hold'>('hold');
  const [sentiment, setSentiment] = useState<'bullish' | 'bearish' | 'neutral'>('neutral');
  const [confidence, setConfidence] = useState<number>(75);
  const { t } = useLanguage();
  
  useEffect(() => {
    // Update signal every 10 seconds
    const updateSignal = () => {
      const prediction = getAIPrediction();
      setSignal(prediction.signal);
      setSentiment(prediction.sentiment);
      setConfidence(prediction.shortTerm.confidence);
    };
    
    updateSignal();
    const interval = setInterval(updateSignal, 10000);
    
    return () => clearInterval(interval);
  }, []);
  
  const getSignalContent = () => {
    switch (signal) {
      case 'buy':
        return {
          icon: <ArrowUpCircle size={36} className="text-success-500" />,
          title: t('buySignal'),
          color: 'text-success-600 dark:text-success-500',
          bgColor: 'bg-success-500/10'
        };
      case 'sell':
        return {
          icon: <ArrowDownCircle size={36} className="text-error-500" />,
          title: t('sellSignal'),
          color: 'text-error-600 dark:text-error-500',
          bgColor: 'bg-error-500/10'
        };
      case 'hold':
      default:
        return {
          icon: <MinusCircle size={36} className="text-warning-500" />,
          title: t('holdSignal'),
          color: 'text-warning-600 dark:text-warning-500',
          bgColor: 'bg-warning-500/10'
        };
    }
  };
  
  const getSentimentContent = () => {
    switch (sentiment) {
      case 'bullish':
        return {
          title: t('bullish'),
          color: 'text-success-600 dark:text-success-500'
        };
      case 'bearish':
        return {
          title: t('bearish'),
          color: 'text-error-600 dark:text-error-500'
        };
      case 'neutral':
      default:
        return {
          title: t('neutral'),
          color: 'text-warning-600 dark:text-warning-500'
        };
    }
  };
  
  const signalContent = getSignalContent();
  const sentimentContent = getSentimentContent();
  
  return (
    <div className="card animate-slide-up">
      <div className="flex justify-between items-center mb-4">
        <h2 className="text-lg font-semibold text-gray-800 dark:text-white">AI {t('buySignal')}</h2>
        <div className={`px-2 py-1 rounded ${signalContent.bgColor}`}>
          <span className={`font-medium ${signalContent.color}`}>{confidence}% {t('confidence')}</span>
        </div>
      </div>
      
      <div className="flex items-center justify-center py-6">
        <div className="flex flex-col items-center">
          {signalContent.icon}
          <div className={`text-xl font-bold mt-3 ${signalContent.color}`}>
            {signalContent.title}
          </div>
        </div>
      </div>
      
      <div className="border-t border-gray-200 dark:border-gray-700 pt-4">
        <div className="flex justify-between">
          <span className="text-gray-500 dark:text-gray-400">{t('marketSentiment')}</span>
          <span className={`font-medium ${sentimentContent.color}`}>{sentimentContent.title}</span>
        </div>
      </div>
    </div>
  );
};

export default SignalCard;
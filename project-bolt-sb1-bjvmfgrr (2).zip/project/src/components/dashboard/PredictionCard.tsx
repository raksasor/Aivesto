import React, { useState, useEffect } from 'react';
import { useLanguage } from '../../context/LanguageContext';
import { getAIPrediction } from '../../services/goldPriceService';
import { TrendingUp, TrendingDown } from 'lucide-react';

interface Prediction {
  price: number;
  change: number;
  confidence: number;
}

interface Predictions {
  shortTerm: Prediction;
  midTerm: Prediction;
  longTerm: Prediction;
}

const PredictionCard: React.FC = () => {
  const [predictions, setPredictions] = useState<Predictions>({
    shortTerm: { price: 0, change: 0, confidence: 0 },
    midTerm: { price: 0, change: 0, confidence: 0 },
    longTerm: { price: 0, change: 0, confidence: 0 }
  });
  const { t } = useLanguage();
  
  useEffect(() => {
    const updatePredictions = () => {
      const aiPrediction = getAIPrediction();
      setPredictions({
        shortTerm: aiPrediction.shortTerm,
        midTerm: aiPrediction.midTerm,
        longTerm: aiPrediction.longTerm
      });
    };
    
    updatePredictions();
    const interval = setInterval(updatePredictions, 15000);
    
    return () => clearInterval(interval);
  }, []);
  
  // Helper function to render prediction item
  const renderPredictionItem = (term: 'shortTerm' | 'midTerm' | 'longTerm', prediction: Prediction) => {
    return (
      <div className="mb-4 last:mb-0">
        <div className="flex justify-between mb-1">
          <span className="text-gray-600 dark:text-gray-400">{t(term)}</span>
          <div className="flex items-center">
            <span className={prediction.change >= 0 ? 'text-success-500' : 'text-error-500'}>
              {prediction.change >= 0 ? '+' : ''}{prediction.change}%
            </span>
            <div className="ml-1">
              {prediction.change >= 0 
                ? <TrendingUp size={14} className="text-success-500" /> 
                : <TrendingDown size={14} className="text-error-500" />}
            </div>
          </div>
        </div>
        
        <div className="flex justify-between">
          <div className="text-xl font-medium">${prediction.price}</div>
          <div className="text-xs text-gray-500">
            <span className="inline-block bg-gray-100 dark:bg-gray-800 px-2 py-1 rounded">
              {prediction.confidence}% {t('confidence')}
            </span>
          </div>
        </div>
        
        {/* Progress bar indicating confidence */}
        <div className="w-full bg-gray-200 dark:bg-gray-700 h-1 mt-2 rounded-full overflow-hidden">
          <div 
            className={`h-full rounded-full ${
              prediction.change >= 0 ? 'bg-gradient-to-r from-primary-500 to-success-500' : 'bg-gradient-to-r from-primary-500 to-error-500'
            }`}
            style={{ width: `${prediction.confidence}%` }}
          ></div>
        </div>
      </div>
    );
  };
  
  return (
    <div className="card animate-slide-up">
      <div className="flex justify-between items-center mb-4">
        <h2 className="text-lg font-semibold text-gray-800 dark:text-white">
          {t('predictions')}
        </h2>
        <div className="text-xs text-gray-500 dark:text-gray-400">
          AI powered
        </div>
      </div>
      
      <div className="p-2">
        {renderPredictionItem('shortTerm', predictions.shortTerm)}
        <div className="border-t border-gray-200 dark:border-gray-700 my-3"></div>
        {renderPredictionItem('midTerm', predictions.midTerm)}
        <div className="border-t border-gray-200 dark:border-gray-700 my-3"></div>
        {renderPredictionItem('longTerm', predictions.longTerm)}
      </div>
    </div>
  );
};

export default PredictionCard;
import React from 'react';
import { 
  Home, 
  TrendingUp, 
  LineChart, 
  Brain, 
  Calculator, 
  Settings, 
  Sun, 
  Moon, 
  Languages
} from 'lucide-react';
import { useLanguage } from '../../context/LanguageContext';
import { useTheme } from '../../context/ThemeContext';

interface SidebarItemProps {
  icon: React.ReactNode;
  label: string;
  active?: boolean;
  onClick: () => void;
}

const SidebarItem: React.FC<SidebarItemProps> = ({ icon, label, active = false, onClick }) => {
  return (
    <div 
      className={`flex items-center p-3 mb-2 rounded-lg cursor-pointer transition-all duration-200 ${
        active 
          ? 'bg-primary-100 dark:bg-primary-900/20 text-primary-600 dark:text-primary-400' 
          : 'hover:bg-gray-100 dark:hover:bg-gray-800 text-gray-700 dark:text-gray-300'
      }`}
      onClick={onClick}
    >
      <div className="mr-3">{icon}</div>
      <span className="font-medium">{label}</span>
    </div>
  );
};

interface SidebarProps {
  activeSection: string;
  onSectionChange: (section: string) => void;
}

const Sidebar: React.FC<SidebarProps> = ({ activeSection, onSectionChange }) => {
  const { t } = useLanguage();
  const { theme, toggleTheme } = useTheme();
  
  return (
    <div className="w-64 h-screen bg-white dark:bg-gray-900 border-l border-gray-200 dark:border-gray-800 p-4 flex flex-col">
      <div className="mb-8 flex items-center justify-center">
        <div className="bg-gradient-to-r from-primary-500 to-secondary-500 text-white font-bold text-xl py-2 px-4 rounded-lg">
          Ai Investor
        </div>
      </div>
      
      <div className="flex-grow">
        <SidebarItem 
          icon={<Home size={20} />} 
          label={t('dashboard')} 
          active={activeSection === 'dashboard'} 
          onClick={() => onSectionChange('dashboard')} 
        />
        <SidebarItem 
          icon={<TrendingUp size={20} />} 
          label={t('realTimePrice')} 
          active={activeSection === 'price'} 
          onClick={() => onSectionChange('price')} 
        />
        <SidebarItem 
          icon={<Brain size={20} />} 
          label={t('aiPrediction')} 
          active={activeSection === 'prediction'} 
          onClick={() => onSectionChange('prediction')} 
        />
        <SidebarItem 
          icon={<LineChart size={20} />} 
          label={t('technicalAnalysis')} 
          active={activeSection === 'technical'} 
          onClick={() => onSectionChange('technical')} 
        />
        <SidebarItem 
          icon={<Calculator size={20} />} 
          label={t('investmentCalculator')} 
          active={activeSection === 'calculator'} 
          onClick={() => onSectionChange('calculator')} 
        />
        <SidebarItem 
          icon={<Settings size={20} />} 
          label={t('settings')} 
          active={activeSection === 'settings'} 
          onClick={() => onSectionChange('settings')} 
        />
      </div>
      
      <div className="flex justify-between pt-4 border-t border-gray-200 dark:border-gray-800">
        <button 
          onClick={toggleTheme}
          className="p-2 rounded-full hover:bg-gray-100 dark:hover:bg-gray-800"
          aria-label={theme === 'dark' ? t('lightMode') : t('darkMode')}
        >
          {theme === 'dark' ? <Sun size={20} /> : <Moon size={20} />}
        </button>
        
        <button 
          className="p-2 rounded-full hover:bg-gray-100 dark:hover:bg-gray-800"
          aria-label={t('language')}
        >
          <Languages size={20} />
        </button>
      </div>
    </div>
  );
};

export default Sidebar;
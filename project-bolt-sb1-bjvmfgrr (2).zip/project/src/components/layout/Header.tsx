import React from 'react';
import { useLanguage } from '../../context/LanguageContext';
import { Bell, User } from 'lucide-react';

const Header: React.FC = () => {
  const { t } = useLanguage();
  
  return (
    <header className="bg-white dark:bg-gray-900 border-b border-gray-200 dark:border-gray-800 py-4 px-6 flex justify-between items-center">
      <h1 className="text-xl font-bold text-gray-800 dark:text-white">{t('dashboard')}</h1>
      
      <div className="flex items-center space-x-4">
        <button 
          className="p-2 rounded-full hover:bg-gray-100 dark:hover:bg-gray-800 text-gray-700 dark:text-gray-300"
          aria-label="Notifications"
        >
          <Bell size={20} />
        </button>
        
        <div className="flex items-center rounded-full bg-gray-100 dark:bg-gray-800 p-1 cursor-pointer">
          <div className="mr-2 bg-primary-500 text-white p-1 rounded-full">
            <User size={18} />
          </div>
          <span className="pr-2 text-sm font-medium text-gray-700 dark:text-gray-300">کاربر</span>
        </div>
      </div>
    </header>
  );
};

export default Header;
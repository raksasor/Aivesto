import React from 'react';
import GoldPriceCard from '../components/dashboard/GoldPriceCard';
import SignalCard from '../components/dashboard/SignalCard';
import PredictionCard from '../components/dashboard/PredictionCard';
import PriceChart from '../components/charts/PriceChart';
import TechnicalIndicators from '../components/charts/TechnicalIndicators';
import InvestmentCalculator from '../components/calculator/InvestmentCalculator';

const Dashboard: React.FC = () => {
  return (
    <div className="p-6">
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 mb-6">
        <GoldPriceCard />
        <SignalCard />
        <PredictionCard />
      </div>
      
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        <div className="lg:col-span-2 space-y-6">
          <PriceChart />
          <TechnicalIndicators />
        </div>
        
        <div>
          <InvestmentCalculator />
        </div>
      </div>
    </div>
  );
};

export default Dashboard;
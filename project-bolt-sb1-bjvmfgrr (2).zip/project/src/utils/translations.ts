export type LanguageKey = 
  | 'dashboard'
  | 'realTimePrice'
  | 'aiPrediction'
  | 'technicalAnalysis'
  | 'investmentCalculator'
  | 'settings'
  | 'goldPrice'
  | 'lastUpdate'
  | 'change24h'
  | 'highPrice'
  | 'lowPrice'
  | 'buySignal'
  | 'sellSignal'
  | 'holdSignal'
  | 'marketSentiment'
  | 'bullish'
  | 'bearish'
  | 'neutral'
  | 'priceChart'
  | 'timeframe'
  | 'rsi'
  | 'macd'
  | 'movingAverages'
  | 'supportResistance'
  | 'investmentAmount'
  | 'predictedReturn'
  | 'calculateReturn'
  | 'investNow'
  | 'darkMode'
  | 'lightMode'
  | 'language'
  | 'predictions'
  | 'shortTerm'
  | 'midTerm'
  | 'longTerm';

type TranslationType = {
  [key in 'fa' | 'en']: {
    [key in LanguageKey]: string;
  };
};

export const translations: TranslationType = {
  fa: {
    // Navigation
    dashboard: 'داشبورد',
    realTimePrice: 'قیمت لحظه‌ای',
    aiPrediction: 'پیش‌بینی هوش مصنوعی',
    technicalAnalysis: 'تحلیل تکنیکال',
    investmentCalculator: 'ماشین حساب سرمایه‌گذاری',
    settings: 'تنظیمات',
    
    // Gold price
    goldPrice: 'قیمت طلا',
    lastUpdate: 'آخرین به‌روزرسانی',
    change24h: 'تغییر ۲۴ ساعته',
    highPrice: 'بالاترین قیمت',
    lowPrice: 'پایین‌ترین قیمت',
    
    // Signals
    buySignal: 'سیگنال خرید',
    sellSignal: 'سیگنال فروش',
    holdSignal: 'سیگنال نگهداری',
    
    // Market sentiment
    marketSentiment: 'احساس بازار',
    bullish: 'صعودی',
    bearish: 'نزولی',
    neutral: 'خنثی',
    
    // Charts
    priceChart: 'نمودار قیمت',
    timeframe: 'بازه زمانی',
    
    // Technical indicators
    rsi: 'شاخص قدرت نسبی (RSI)',
    macd: 'واگرایی/همگرایی میانگین متحرک (MACD)',
    movingAverages: 'میانگین متحرک',
    supportResistance: 'سطوح حمایت و مقاومت',
    
    // Calculator
    investmentAmount: 'مقدار سرمایه‌گذاری',
    predictedReturn: 'بازده پیش‌بینی شده',
    calculateReturn: 'محاسبه بازده',
    investNow: 'سرمایه‌گذاری کنید',
    
    // Settings
    darkMode: 'حالت تاریک',
    lightMode: 'حالت روشن',
    language: 'زبان',
    
    // Predictions
    predictions: 'پیش‌بینی‌ها',
    shortTerm: 'کوتاه مدت',
    midTerm: 'میان مدت',
    longTerm: 'بلند مدت'
  },
  en: {
    // Navigation
    dashboard: 'Dashboard',
    realTimePrice: 'Real-time Price',
    aiPrediction: 'AI Prediction',
    technicalAnalysis: 'Technical Analysis',
    investmentCalculator: 'Investment Calculator',
    settings: 'Settings',
    
    // Gold price
    goldPrice: 'Gold Price',
    lastUpdate: 'Last Update',
    change24h: '24h Change',
    highPrice: 'High Price',
    lowPrice: 'Low Price',
    
    // Signals
    buySignal: 'Buy Signal',
    sellSignal: 'Sell Signal',
    holdSignal: 'Hold Signal',
    
    // Market sentiment
    marketSentiment: 'Market Sentiment',
    bullish: 'Bullish',
    bearish: 'Bearish',
    neutral: 'Neutral',
    
    // Charts
    priceChart: 'Price Chart',
    timeframe: 'Timeframe',
    
    // Technical indicators
    rsi: 'Relative Strength Index (RSI)',
    macd: 'Moving Average Convergence Divergence (MACD)',
    movingAverages: 'Moving Averages',
    supportResistance: 'Support & Resistance',
    
    // Calculator
    investmentAmount: 'Investment Amount',
    predictedReturn: 'Predicted Return',
    calculateReturn: 'Calculate Return',
    investNow: 'Invest Now',
    
    // Settings
    darkMode: 'Dark Mode',
    lightMode: 'Light Mode',
    language: 'Language',
    
    // Predictions
    predictions: 'Predictions',
    shortTerm: 'Short Term',
    midTerm: 'Mid Term',
    longTerm: 'Long Term'
  }
};
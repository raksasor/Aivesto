import React, { createContext, useContext, useState, ReactNode } from 'react';
import { translations, LanguageKey } from '../utils/translations';

type LanguageType = 'fa' | 'en';

interface LanguageContextType {
  language: LanguageType;
  toggleLanguage: () => void;
  t: (key: LanguageKey) => string;
}

const LanguageContext = createContext<LanguageContextType | undefined>(undefined);

export const LanguageProvider: React.FC<{ children: ReactNode }> = ({ children }) => {
  const [language, setLanguage] = useState<LanguageType>('fa');

  const toggleLanguage = () => {
    setLanguage(prevLang => (prevLang === 'fa' ? 'en' : 'fa'));
    document.documentElement.dir = language === 'fa' ? 'ltr' : 'rtl';
    document.documentElement.lang = language === 'fa' ? 'en' : 'fa';
  };

  const t = (key: LanguageKey): string => {
    return translations[language][key] || key;
  };

  return (
    <LanguageContext.Provider value={{ language, toggleLanguage, t }}>
      {children}
    </LanguageContext.Provider>
  );
};

export const useLanguage = (): LanguageContextType => {
  const context = useContext(LanguageContext);
  if (context === undefined) {
    throw new Error('useLanguage must be used within a LanguageProvider');
  }
  return context;
};